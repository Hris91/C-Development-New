﻿
namespace P01_HospitalDatabase.Data
{
    class Configuration
    {
        public static string ConnectionString { get; set; } 
            = @"Server=DESKTOP-ODF3207\SQLEXPRESS;Database=Hospital;Integrated Security=True";
    }
}
