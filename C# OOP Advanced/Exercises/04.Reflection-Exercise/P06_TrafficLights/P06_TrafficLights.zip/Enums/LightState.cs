﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P06_TrafficLights.Enums
{
    public enum LightState
    {
        Green = 1,
        Yellow = 2,
        Red = 3
    }
}
